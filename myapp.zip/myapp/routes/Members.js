const fs = require('fs');
const members = JSON.parse(fs.readFileSync('../data/members.json', 'utf8'));
module.exports={
    memberIndexByEmail:function(email)
    {
        var i;
        for (i=0; i<members.length; i++)
        {
            if (members[i]["email"]==email)
            {
                return i;
            }
        }
        return (-1);
    },
    memberIndexByUsername:function(username)
    {
        var i;
        for (i=0; i<members.length; i++)
        {
            if (members[i]["username"]==username)
            {
                return i;
            }
        }
        return (-1);
    },
    memberExist:function(index,password)
    {
        if (members[index]["password"]==password)
        {
            return true;
        }
        return false;
    },
    addMember:function(username,password,email)
    {
        members.push({
            "username" : username,
            "password" : password,
            "email"    : email
        });
        fs.writeFileSync('../data/members.json',JSON.stringify(members));

    }
};

