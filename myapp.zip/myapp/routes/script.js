const Joi = require('joi');
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const Members = require('./Members');
const app = express();
const createUserSchema = Joi.object().keys({
    username: Joi.string().alphanum().min(2).max(30).required(),
    password: Joi.string().min(2).max(30).required(),
    email: Joi.string().email().required(),
    sign: Joi.allow(),
});
app.use(bodyParser.urlencoded());

app.get('/',(req,res) => {
    res.sendFile(path.resolve("../views/index.html"));
});


app.get('/login',(req,res) => {
    res.sendFile(path.resolve("../views/login.html"));
});
app.get('/sign',(req,res) => {
    res.sendFile(path.resolve('../views/sign.html'));
});

app.post('/login',(req,res) => {
    var index = Math.max(Members.memberIndexByUsername(req.body.username),Members.memberIndexByEmail(req.body.email));
    if (index==-1)
    {
        res.send("Username/Email doesn't exist");
    }
    else
    {
        if (Members.memberExist(index,req.body.password))
        {
            res.sendFile(path.resolve('../views/home.html'));
        }
        else
        {
            res.send('Wrong password');
        }
    }
});
app.post('/sign',(req,res) => {
        createUserSchema.validate(req.body, {abortEarly: false}) //abortEarly - collect all errors not just the first one
            .then(validatedUser => {
                var index = Math.max(Members.memberIndexByUsername(req.body.username),Members.memberIndexByEmail(req.body.email));
                if (index!=-1)
                {
                    res.send("Username/Email already exists");
                }
                else
                {
                    Members.addMember(req.body.username,req.body.password,req.body.email);
                    console.log(`user ${JSON.stringify(validatedUser)} created`);
                    res.sendFile(path.resolve('../views/login.html'));
                }
                
            })
            .catch(validationError => {
                const errorMessage = validationError.details.map(d => d.message);
                console.log(errorMessage);
            });
    
});




const port = process.env.PORT || 3000 ;

app.listen(port, () => console.log(`listening on port ${port} `));
